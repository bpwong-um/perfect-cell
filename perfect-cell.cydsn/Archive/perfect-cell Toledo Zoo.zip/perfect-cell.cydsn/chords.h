int construct_chords_route(char *route, char *labels[], float readings[],
                        int nvars, int instrument_id, int write_key_enabled, 
                        char *chords_write_key, int is_test);

/* [] END OF FILE */
