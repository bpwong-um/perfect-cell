/*******************************************************************************
* File Name: Telit_tx.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Telit_tx_H) /* Pins Telit_tx_H */
#define CY_PINS_Telit_tx_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Telit_tx_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Telit_tx__PORT == 15 && ((Telit_tx__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Telit_tx_Write(uint8 value);
void    Telit_tx_SetDriveMode(uint8 mode);
uint8   Telit_tx_ReadDataReg(void);
uint8   Telit_tx_Read(void);
void    Telit_tx_SetInterruptMode(uint16 position, uint16 mode);
uint8   Telit_tx_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Telit_tx_SetDriveMode() function.
     *  @{
     */
        #define Telit_tx_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Telit_tx_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Telit_tx_DM_RES_UP          PIN_DM_RES_UP
        #define Telit_tx_DM_RES_DWN         PIN_DM_RES_DWN
        #define Telit_tx_DM_OD_LO           PIN_DM_OD_LO
        #define Telit_tx_DM_OD_HI           PIN_DM_OD_HI
        #define Telit_tx_DM_STRONG          PIN_DM_STRONG
        #define Telit_tx_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Telit_tx_MASK               Telit_tx__MASK
#define Telit_tx_SHIFT              Telit_tx__SHIFT
#define Telit_tx_WIDTH              1u

/* Interrupt constants */
#if defined(Telit_tx__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Telit_tx_SetInterruptMode() function.
     *  @{
     */
        #define Telit_tx_INTR_NONE      (uint16)(0x0000u)
        #define Telit_tx_INTR_RISING    (uint16)(0x0001u)
        #define Telit_tx_INTR_FALLING   (uint16)(0x0002u)
        #define Telit_tx_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Telit_tx_INTR_MASK      (0x01u) 
#endif /* (Telit_tx__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Telit_tx_PS                     (* (reg8 *) Telit_tx__PS)
/* Data Register */
#define Telit_tx_DR                     (* (reg8 *) Telit_tx__DR)
/* Port Number */
#define Telit_tx_PRT_NUM                (* (reg8 *) Telit_tx__PRT) 
/* Connect to Analog Globals */                                                  
#define Telit_tx_AG                     (* (reg8 *) Telit_tx__AG)                       
/* Analog MUX bux enable */
#define Telit_tx_AMUX                   (* (reg8 *) Telit_tx__AMUX) 
/* Bidirectional Enable */                                                        
#define Telit_tx_BIE                    (* (reg8 *) Telit_tx__BIE)
/* Bit-mask for Aliased Register Access */
#define Telit_tx_BIT_MASK               (* (reg8 *) Telit_tx__BIT_MASK)
/* Bypass Enable */
#define Telit_tx_BYP                    (* (reg8 *) Telit_tx__BYP)
/* Port wide control signals */                                                   
#define Telit_tx_CTL                    (* (reg8 *) Telit_tx__CTL)
/* Drive Modes */
#define Telit_tx_DM0                    (* (reg8 *) Telit_tx__DM0) 
#define Telit_tx_DM1                    (* (reg8 *) Telit_tx__DM1)
#define Telit_tx_DM2                    (* (reg8 *) Telit_tx__DM2) 
/* Input Buffer Disable Override */
#define Telit_tx_INP_DIS                (* (reg8 *) Telit_tx__INP_DIS)
/* LCD Common or Segment Drive */
#define Telit_tx_LCD_COM_SEG            (* (reg8 *) Telit_tx__LCD_COM_SEG)
/* Enable Segment LCD */
#define Telit_tx_LCD_EN                 (* (reg8 *) Telit_tx__LCD_EN)
/* Slew Rate Control */
#define Telit_tx_SLW                    (* (reg8 *) Telit_tx__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Telit_tx_PRTDSI__CAPS_SEL       (* (reg8 *) Telit_tx__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Telit_tx_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Telit_tx__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Telit_tx_PRTDSI__OE_SEL0        (* (reg8 *) Telit_tx__PRTDSI__OE_SEL0) 
#define Telit_tx_PRTDSI__OE_SEL1        (* (reg8 *) Telit_tx__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Telit_tx_PRTDSI__OUT_SEL0       (* (reg8 *) Telit_tx__PRTDSI__OUT_SEL0) 
#define Telit_tx_PRTDSI__OUT_SEL1       (* (reg8 *) Telit_tx__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Telit_tx_PRTDSI__SYNC_OUT       (* (reg8 *) Telit_tx__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Telit_tx__SIO_CFG)
    #define Telit_tx_SIO_HYST_EN        (* (reg8 *) Telit_tx__SIO_HYST_EN)
    #define Telit_tx_SIO_REG_HIFREQ     (* (reg8 *) Telit_tx__SIO_REG_HIFREQ)
    #define Telit_tx_SIO_CFG            (* (reg8 *) Telit_tx__SIO_CFG)
    #define Telit_tx_SIO_DIFF           (* (reg8 *) Telit_tx__SIO_DIFF)
#endif /* (Telit_tx__SIO_CFG) */

/* Interrupt Registers */
#if defined(Telit_tx__INTSTAT)
    #define Telit_tx_INTSTAT            (* (reg8 *) Telit_tx__INTSTAT)
    #define Telit_tx_SNAP               (* (reg8 *) Telit_tx__SNAP)
    
	#define Telit_tx_0_INTTYPE_REG 		(* (reg8 *) Telit_tx__0__INTTYPE)
#endif /* (Telit_tx__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Telit_tx_H */


/* [] END OF FILE */
