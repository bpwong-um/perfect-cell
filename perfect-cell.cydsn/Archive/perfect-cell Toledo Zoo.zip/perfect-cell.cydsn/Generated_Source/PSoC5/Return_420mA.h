/*******************************************************************************
* File Name: Return_420mA.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Return_420mA_H) /* Pins Return_420mA_H */
#define CY_PINS_Return_420mA_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Return_420mA_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Return_420mA__PORT == 15 && ((Return_420mA__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Return_420mA_Write(uint8 value);
void    Return_420mA_SetDriveMode(uint8 mode);
uint8   Return_420mA_ReadDataReg(void);
uint8   Return_420mA_Read(void);
void    Return_420mA_SetInterruptMode(uint16 position, uint16 mode);
uint8   Return_420mA_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Return_420mA_SetDriveMode() function.
     *  @{
     */
        #define Return_420mA_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Return_420mA_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Return_420mA_DM_RES_UP          PIN_DM_RES_UP
        #define Return_420mA_DM_RES_DWN         PIN_DM_RES_DWN
        #define Return_420mA_DM_OD_LO           PIN_DM_OD_LO
        #define Return_420mA_DM_OD_HI           PIN_DM_OD_HI
        #define Return_420mA_DM_STRONG          PIN_DM_STRONG
        #define Return_420mA_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Return_420mA_MASK               Return_420mA__MASK
#define Return_420mA_SHIFT              Return_420mA__SHIFT
#define Return_420mA_WIDTH              1u

/* Interrupt constants */
#if defined(Return_420mA__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Return_420mA_SetInterruptMode() function.
     *  @{
     */
        #define Return_420mA_INTR_NONE      (uint16)(0x0000u)
        #define Return_420mA_INTR_RISING    (uint16)(0x0001u)
        #define Return_420mA_INTR_FALLING   (uint16)(0x0002u)
        #define Return_420mA_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Return_420mA_INTR_MASK      (0x01u) 
#endif /* (Return_420mA__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Return_420mA_PS                     (* (reg8 *) Return_420mA__PS)
/* Data Register */
#define Return_420mA_DR                     (* (reg8 *) Return_420mA__DR)
/* Port Number */
#define Return_420mA_PRT_NUM                (* (reg8 *) Return_420mA__PRT) 
/* Connect to Analog Globals */                                                  
#define Return_420mA_AG                     (* (reg8 *) Return_420mA__AG)                       
/* Analog MUX bux enable */
#define Return_420mA_AMUX                   (* (reg8 *) Return_420mA__AMUX) 
/* Bidirectional Enable */                                                        
#define Return_420mA_BIE                    (* (reg8 *) Return_420mA__BIE)
/* Bit-mask for Aliased Register Access */
#define Return_420mA_BIT_MASK               (* (reg8 *) Return_420mA__BIT_MASK)
/* Bypass Enable */
#define Return_420mA_BYP                    (* (reg8 *) Return_420mA__BYP)
/* Port wide control signals */                                                   
#define Return_420mA_CTL                    (* (reg8 *) Return_420mA__CTL)
/* Drive Modes */
#define Return_420mA_DM0                    (* (reg8 *) Return_420mA__DM0) 
#define Return_420mA_DM1                    (* (reg8 *) Return_420mA__DM1)
#define Return_420mA_DM2                    (* (reg8 *) Return_420mA__DM2) 
/* Input Buffer Disable Override */
#define Return_420mA_INP_DIS                (* (reg8 *) Return_420mA__INP_DIS)
/* LCD Common or Segment Drive */
#define Return_420mA_LCD_COM_SEG            (* (reg8 *) Return_420mA__LCD_COM_SEG)
/* Enable Segment LCD */
#define Return_420mA_LCD_EN                 (* (reg8 *) Return_420mA__LCD_EN)
/* Slew Rate Control */
#define Return_420mA_SLW                    (* (reg8 *) Return_420mA__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Return_420mA_PRTDSI__CAPS_SEL       (* (reg8 *) Return_420mA__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Return_420mA_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Return_420mA__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Return_420mA_PRTDSI__OE_SEL0        (* (reg8 *) Return_420mA__PRTDSI__OE_SEL0) 
#define Return_420mA_PRTDSI__OE_SEL1        (* (reg8 *) Return_420mA__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Return_420mA_PRTDSI__OUT_SEL0       (* (reg8 *) Return_420mA__PRTDSI__OUT_SEL0) 
#define Return_420mA_PRTDSI__OUT_SEL1       (* (reg8 *) Return_420mA__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Return_420mA_PRTDSI__SYNC_OUT       (* (reg8 *) Return_420mA__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Return_420mA__SIO_CFG)
    #define Return_420mA_SIO_HYST_EN        (* (reg8 *) Return_420mA__SIO_HYST_EN)
    #define Return_420mA_SIO_REG_HIFREQ     (* (reg8 *) Return_420mA__SIO_REG_HIFREQ)
    #define Return_420mA_SIO_CFG            (* (reg8 *) Return_420mA__SIO_CFG)
    #define Return_420mA_SIO_DIFF           (* (reg8 *) Return_420mA__SIO_DIFF)
#endif /* (Return_420mA__SIO_CFG) */

/* Interrupt Registers */
#if defined(Return_420mA__INTSTAT)
    #define Return_420mA_INTSTAT            (* (reg8 *) Return_420mA__INTSTAT)
    #define Return_420mA_SNAP               (* (reg8 *) Return_420mA__SNAP)
    
	#define Return_420mA_0_INTTYPE_REG 		(* (reg8 *) Return_420mA__0__INTTYPE)
#endif /* (Return_420mA__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Return_420mA_H */


/* [] END OF FILE */
