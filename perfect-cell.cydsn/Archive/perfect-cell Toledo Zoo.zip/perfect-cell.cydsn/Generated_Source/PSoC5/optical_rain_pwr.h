/*******************************************************************************
* File Name: optical_rain_pwr.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_optical_rain_pwr_H) /* Pins optical_rain_pwr_H */
#define CY_PINS_optical_rain_pwr_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "optical_rain_pwr_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 optical_rain_pwr__PORT == 15 && ((optical_rain_pwr__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    optical_rain_pwr_Write(uint8 value);
void    optical_rain_pwr_SetDriveMode(uint8 mode);
uint8   optical_rain_pwr_ReadDataReg(void);
uint8   optical_rain_pwr_Read(void);
void    optical_rain_pwr_SetInterruptMode(uint16 position, uint16 mode);
uint8   optical_rain_pwr_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the optical_rain_pwr_SetDriveMode() function.
     *  @{
     */
        #define optical_rain_pwr_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define optical_rain_pwr_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define optical_rain_pwr_DM_RES_UP          PIN_DM_RES_UP
        #define optical_rain_pwr_DM_RES_DWN         PIN_DM_RES_DWN
        #define optical_rain_pwr_DM_OD_LO           PIN_DM_OD_LO
        #define optical_rain_pwr_DM_OD_HI           PIN_DM_OD_HI
        #define optical_rain_pwr_DM_STRONG          PIN_DM_STRONG
        #define optical_rain_pwr_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define optical_rain_pwr_MASK               optical_rain_pwr__MASK
#define optical_rain_pwr_SHIFT              optical_rain_pwr__SHIFT
#define optical_rain_pwr_WIDTH              1u

/* Interrupt constants */
#if defined(optical_rain_pwr__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in optical_rain_pwr_SetInterruptMode() function.
     *  @{
     */
        #define optical_rain_pwr_INTR_NONE      (uint16)(0x0000u)
        #define optical_rain_pwr_INTR_RISING    (uint16)(0x0001u)
        #define optical_rain_pwr_INTR_FALLING   (uint16)(0x0002u)
        #define optical_rain_pwr_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define optical_rain_pwr_INTR_MASK      (0x01u) 
#endif /* (optical_rain_pwr__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define optical_rain_pwr_PS                     (* (reg8 *) optical_rain_pwr__PS)
/* Data Register */
#define optical_rain_pwr_DR                     (* (reg8 *) optical_rain_pwr__DR)
/* Port Number */
#define optical_rain_pwr_PRT_NUM                (* (reg8 *) optical_rain_pwr__PRT) 
/* Connect to Analog Globals */                                                  
#define optical_rain_pwr_AG                     (* (reg8 *) optical_rain_pwr__AG)                       
/* Analog MUX bux enable */
#define optical_rain_pwr_AMUX                   (* (reg8 *) optical_rain_pwr__AMUX) 
/* Bidirectional Enable */                                                        
#define optical_rain_pwr_BIE                    (* (reg8 *) optical_rain_pwr__BIE)
/* Bit-mask for Aliased Register Access */
#define optical_rain_pwr_BIT_MASK               (* (reg8 *) optical_rain_pwr__BIT_MASK)
/* Bypass Enable */
#define optical_rain_pwr_BYP                    (* (reg8 *) optical_rain_pwr__BYP)
/* Port wide control signals */                                                   
#define optical_rain_pwr_CTL                    (* (reg8 *) optical_rain_pwr__CTL)
/* Drive Modes */
#define optical_rain_pwr_DM0                    (* (reg8 *) optical_rain_pwr__DM0) 
#define optical_rain_pwr_DM1                    (* (reg8 *) optical_rain_pwr__DM1)
#define optical_rain_pwr_DM2                    (* (reg8 *) optical_rain_pwr__DM2) 
/* Input Buffer Disable Override */
#define optical_rain_pwr_INP_DIS                (* (reg8 *) optical_rain_pwr__INP_DIS)
/* LCD Common or Segment Drive */
#define optical_rain_pwr_LCD_COM_SEG            (* (reg8 *) optical_rain_pwr__LCD_COM_SEG)
/* Enable Segment LCD */
#define optical_rain_pwr_LCD_EN                 (* (reg8 *) optical_rain_pwr__LCD_EN)
/* Slew Rate Control */
#define optical_rain_pwr_SLW                    (* (reg8 *) optical_rain_pwr__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define optical_rain_pwr_PRTDSI__CAPS_SEL       (* (reg8 *) optical_rain_pwr__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define optical_rain_pwr_PRTDSI__DBL_SYNC_IN    (* (reg8 *) optical_rain_pwr__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define optical_rain_pwr_PRTDSI__OE_SEL0        (* (reg8 *) optical_rain_pwr__PRTDSI__OE_SEL0) 
#define optical_rain_pwr_PRTDSI__OE_SEL1        (* (reg8 *) optical_rain_pwr__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define optical_rain_pwr_PRTDSI__OUT_SEL0       (* (reg8 *) optical_rain_pwr__PRTDSI__OUT_SEL0) 
#define optical_rain_pwr_PRTDSI__OUT_SEL1       (* (reg8 *) optical_rain_pwr__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define optical_rain_pwr_PRTDSI__SYNC_OUT       (* (reg8 *) optical_rain_pwr__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(optical_rain_pwr__SIO_CFG)
    #define optical_rain_pwr_SIO_HYST_EN        (* (reg8 *) optical_rain_pwr__SIO_HYST_EN)
    #define optical_rain_pwr_SIO_REG_HIFREQ     (* (reg8 *) optical_rain_pwr__SIO_REG_HIFREQ)
    #define optical_rain_pwr_SIO_CFG            (* (reg8 *) optical_rain_pwr__SIO_CFG)
    #define optical_rain_pwr_SIO_DIFF           (* (reg8 *) optical_rain_pwr__SIO_DIFF)
#endif /* (optical_rain_pwr__SIO_CFG) */

/* Interrupt Registers */
#if defined(optical_rain_pwr__INTSTAT)
    #define optical_rain_pwr_INTSTAT            (* (reg8 *) optical_rain_pwr__INTSTAT)
    #define optical_rain_pwr_SNAP               (* (reg8 *) optical_rain_pwr__SNAP)
    
	#define optical_rain_pwr_0_INTTYPE_REG 		(* (reg8 *) optical_rain_pwr__0__INTTYPE)
#endif /* (optical_rain_pwr__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_optical_rain_pwr_H */


/* [] END OF FILE */
